<li class="bnr-sidebar">
	<a href="<?php echo (of_get_option('bnr_sidebar_url')!='') ? of_get_option('bnr_sidebar_url') : '#'; ?>" target="_blank"><img src="<?php echo of_get_option('bnr_sidebar'); ?>" alt=""></a>
</li>