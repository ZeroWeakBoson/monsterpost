<!-- BEGIN ADV CONTENT -->
<div class="bnr-content post-tile">
	<a href="<?php echo (of_get_option('bnr_content_url')!='') ? of_get_option('bnr_content_url') : '#'; ?>"><img src="<?php echo of_get_option('bnr_content'); ?>" alt=""></a>
</div>
<!-- END ADV CONTENT -->