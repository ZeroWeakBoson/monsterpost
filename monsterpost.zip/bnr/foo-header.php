<!-- BEGIN ADV TOP -->
<div class="bnr-top hidden-phone clearfix">
	<a href="<?php echo (of_get_option('bnr_top_url')!='') ? of_get_option('bnr_top_url') : '#'; ?>" target="_blank"><img src="<?php echo of_get_option('bnr_top'); ?>" alt=""></a>
</div>
<!-- END ADV TOP -->