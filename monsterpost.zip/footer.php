	<?php get_template_part('foot'); ?>
		
	<?php wp_footer(); ?> <!-- this is used by many Wordpress features and for plugins to work properly -->
	<?php if(of_get_option('ga_code')) { ?>
		<script type="text/javascript">
			<?php echo stripslashes(of_get_option('ga_code')); ?>
		</script>
	 	<!-- Show Google Analytics -->
	<?php } ?>
</body>
</html>