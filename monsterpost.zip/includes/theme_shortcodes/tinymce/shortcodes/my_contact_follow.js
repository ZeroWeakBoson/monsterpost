frameworkShortcodeAtts={
	attributes:[
			{
				label:"Facebook URL:",
				id:"facebook"
			},
			{
				label:"Twitter URL:",
				id:"twitter"
			},
			{
				label:"Google+ URL:",
				id:"google_plus"
			},
			{
				label:"Pinterest URL:",
				id:"pinterest"
			},
			{
				label:"Dribbble URL:",
				id:"dribbble"
			},
			{
				label:"Behance URL:",
				id:"behance"
			}
	],
	defaultContent:"",
	shortcode:"contact_follow"
};