frameworkShortcodeAtts={
	attributes:[
			{
				label:"List class",
				id:"class",
				controlType:"select-control",
				selectValues:['check', 'check2', 'arrow', 'arrow2', 'star', 'plus', 'minus'],
				defaultValue: 'check', 
				defaultText: 'check',
				help:"Choose list class."
			}
	],
	defaultContent:"",
	shortcode:"tags"
};