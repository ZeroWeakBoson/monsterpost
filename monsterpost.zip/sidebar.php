<aside id="sidebar" class="sidebar span4 hidden-phone">
	<?php if ( ! dynamic_sidebar( 'Sidebar' )) : ?>
	<?php endif; ?>
</aside><!--.sidebar-->